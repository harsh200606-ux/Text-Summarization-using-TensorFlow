import { useState } from "react";

function App() {
  const [text, setText] = useState("");
  const [summary, setSummary] = useState("");

  async function handleSummarize() {
    const res = await fetch("http://127.0.0.1:5000/summarize", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ text })
    });
    const data = await res.json();
    setSummary(data.summary || data.error);
  }

  return (
    <div>
      <h1>Text Summarizer</h1>
      <textarea onChange={e=>setText(e.target.value)} />
      <button onClick={handleSummarize}>Summarize</button>
      <p>{summary}</p>
    </div>
  );
}

export default App;
